##CALLING LIBRARIES
library(dplyr)
library(tidymodels)
##install.packages("randomForest")
library(randomForest)
##install.packages("ggplot2")
library(ggplot2)
##install.packages("caret")
library(caret)
##install.packages("class")
library(class)
library(rpart)
##install.packages("rpart.plot")  
library(rpart.plot)
##install.packages("neuralnet")
library(neuralnet)
install.packages("pROC")
library(pROC)

##Meta data: https://www.kaggle.com/datasets/stoney71/aflstats

##UPLOAD DATASETS
setwd("C:/Users/USER/Desktop/Main Dataset/Australia football")
df1<-read.csv("players.csv")
glimpse(df1)
View(df1)

df2<-read.csv("stats.csv")
glimpse(df2)
View(df2)


##JOINING THE 2 DATASETS WITH "playerId" AS THE COMMON FEATURE
player_stats<- left_join(df1, df2, by ="playerId", suffix = c(".df1", ".df2"), 
                        relationship = "many-to-many")
glimpse(player_stats)

##SETTING SEED
set.seed(3084322)

##CHECKING FOR MISSING VALUES
sum(is.na(player_stats))


##SELECT VARIABLES OF INTEREST
player_stats1<-player_stats%>%
  select(gameNumber, Disposals, Kicks, Marks, Handballs,Goals, Tackles, Rebounds, Inside.50s, Clearances, Clangers,
         Contested.Possessions, Uncontested.Possessions, Contested.Marks, Marks.Inside.50,
         One.Percenters, Goal.Assists, Percentage.Played)

glimpse(player_stats1)

##ADDING A NEW COLUMN TO THE SELECTED VARIABLES OF INTEREST
player_stats2 <- player_stats1 %>%
  mutate(category = case_when(
    Percentage.Played >= 76 ~ "Excellent",
    Percentage.Played >= 51 ~ "Good",
    Percentage.Played >= 26 ~ "Average",
    TRUE ~ "Poor"
  ))

glimpse(player_stats2)
view(player_stats2)

###CREATING FACTORS FOR MY DATASET##  
player_stats3 <- within (player_stats2,{
  category <- factor (category, levels = c("Poor", "Average", "Good", "Excellent"),
                             labels = c("1", "2", "3", "4"))
})

glimpse(player_stats3)

##REMOVING MISSING VALUES IF ANY
clean_player_stats<- na.omit(player_stats3)
glimpse(clean_player_stats)

###PARTITIONING MY DATASET INTO 70% TRAINING, 30% TESTING
player_stats_slipt<-initial_split(clean_player_stats,prop = 0.70,
                                  strata = category)

###POPULATING THE TRAINING DATASET
player_stats_training<- player_stats_slipt%>%
  training()

###POPULATING THE TESTING DATASET
player_stats_testing<- player_stats_slipt%>%
  testing()

glimpse(player_stats_training)
glimpse(player_stats_testing)

###FINDING CORRELATED PREDICTOR VARIABLES
player_stats_training%>%
  select_if(is.numeric)%>%
  cor()

###BUILDING FEATURE ENGINEERING PIPELINE
player_stats_recipe_norm <- recipe( category ~ .,
                             data = player_stats_training)%>%
  step_corr(all_numeric(), threshold = 0.9)%>%
  step_normalize(all_numeric(),-all_outcomes())

player_stats_recipe_norm


##TRAINING AND APPLYING THE RECIPE AFTER PRE-PROCESSING
player_stats_recipe_norm%>%
  prep(training = player_stats_training)%>%
  bake(new_data = player_stats_testing)

###TRAINING OUR RECIPE WITH PREP FUNCTION

player_stats_recipe_prep<- player_stats_recipe_norm%>%
  prep(training = player_stats_training)

player_stats_recipe_prep


###PREPROCESS TRAINING DATASET
player_stats_training_prep<- player_stats_recipe_prep%>%
  bake(new_data = NULL)

glimpse(player_stats_training_prep)


###PREPROCESS TEST DATASET
player_stats_testing_prep<- player_stats_recipe_prep%>%
  bake(new_data = player_stats_testing )
##########################################################################################
##APPLICATION OF MACHINE LEARNING MODELS
###RANDOM FOREST MODEL

randmodel <- randomForest(formula = category~.,
                          data = player_stats_training_prep,
                          ntree = 50)

randmodel


randmode2 <- randomForest(formula = category~.,
                          data = player_stats_training_prep,
                          ntree = 110)

randmode2

###PREDICTION WITH RAND FOREST
class_prediction <- predict(randmodel, 
                            newdata = player_stats_testing_prep,
                            type = "class")
class_prediction


###CALCULATING THE CONFUSION MATRIX

cm <- confusionMatrix(data = class_prediction,
                      reference = player_stats_testing_prep$category)
cm



##ADJUSTING THE WIDTH AND HEIGHT AS NEEDED FOR VISUALIZATION
pdf("randmodel.pdf", width = 10, height = 8)

dev.off()


#IMPORTANT FEATUERS IN A RANDOM FOREST
randmodel3 <- randomForest(clean_player_stats,
                           data = clean_player_stats,
                           ntree = 50,
                           importance = TRUE)

#VISUALIZE THE IMPORTANCE
randomForest::varImpPlot(randmodel,
                         sort= TRUE,
                         main="Variable Importance Plot")


####### AUC ROC CURVE FOR RANDOM FOREST

# Get unique class labels
class_labels <- unique(player_stats_testing_prep$category)

# Function to convert multiclass to binary for a specific class
convert_to_binary <- function(class_label, player_stats_testing_prep) {
  binary_labels <- ifelse(player_stats_testing_prep == class_label, "Positive", "Negative")
  return(factor(binary_labels, levels = c("Positive", "Negative")))
}


# Calculate ROC curves and AUC values for each class
roc_curves <- lapply(class_labels, function(class_label) {
  binary_actual <- convert_to_binary(class_label, player_stats_testing_prep$category)
  binary_predicted <- convert_to_binary(class_label, class_prediction)
  return(roc(binary_actual, as.numeric(binary_predicted)))
})

# Plot ROC curves for each class
plot(roc_curves[[1]], col = "blue", main = "ROC Curves for Random Forest", ExcellentGoodAveragePoor = 2)
for (i in 2:length(roc_curves)) {
  plot(roc_curves[[i]], add = TRUE, col = rainbow(length(class_labels))[i], ExcellentGoodAveragePoor = 2)
}

# Calculate macro-average AUC value
auc_values <- sapply(roc_curves, function(x) x$auc)
macro_auc_value <- mean(auc_values)

# Print macro-average AUC value
cat("Macro-average AUC-ROC value:", macro_auc_value, "\n")

# Add diagonal reference line for random classification
abline(a = 0, b = 1, lty = 2, col = "red")

# Add legend
legend("bottomright", legend = paste("Class", class_labels, "AUC =", 
                                     round(auc_values, 2)), col = rainbow(length(class_labels)),ExcellentGoodAveragePoor=2)



############################################################################################################################
##KNN MODEL

## USING BOTH CATEGORICAL AND NUMERIC DATASET
glimpse(player_stats2)


##VIEWING SUM OF MISSING VALUES
sum(is.na(player_stats2))

##EXAMINING THE STRUCTURE OF THE DATASET
str(player_stats2)

##COUNTING THE NUMBER OF PLAYER STATS UNDER EACH CATEGORY
table(player_stats2$category)


###PARTITIONING MY DATASET INTO 70% TRAINING, 30% TESTING
player_stats_slipt<-initial_split(player_stats2,prop = 0.7,
                                  strata = category)


###POPULATING THE TRAINING DATASET
player_stats_train<- player_stats_slipt%>%
  training()

###POPULATING THE TESTING DATASET
player_stats_test<- player_stats_slipt%>%
  testing()

glimpse(player_stats_train)
glimpse(player_stats_test)


###CREATING TRAIN LABELS
train_labels <- player_stats_train$category

###FIT KNN MODEL
stats_Pred <-knn(train = player_stats_train[-19], test = player_stats_test[-19], cl= train_labels )

stats_Pred

stats_actual <- player_stats_test$category

#CREATING A CONFUSION MATRIX
cm_matrix<- table(stats_Pred,stats_actual)

cm_matrix


#TP: 369+14421+2243+251 = 17284
#FP: (sum of all values in corresponding columns except TP): (0+15+11) + (0+241+0) + (12+323+0) + (9+0+0)=611
#FN: (sum of all values in corresponding rows except TP): (0+12+9) + (0+323+0) + (15+241+0) + (11+0+0)= 611
#TN: 0

## VISUALIZATION 
# CREATING A HEATMAP USING CONFUSION MATRIX
heatmap(cm_matrix, 
        col = cm.colors(256),  
        scale = "none",        
        margins = c(2, 5),    
        main = "Confusion Matrix",
        xlab = "stats_actual",
        ylab = "stats_Pred")

#ACCURACY OF THE MODEL
mean(stats_Pred == stats_actual)

######################################################################################################


##DECISION TREE MODEL

## USING BOTH CATEGORICAL AND NUMERIC DATASET
glimpse(player_stats2)

###PARTITIONING MY DATASET INTO 70% TRAINING, 30% TESTING
player_stats_slipt<-initial_split(player_stats2,prop = 0.7,
                                  strata = category)


###POPULATING THE TRAINING DATASET
player_stats_train<- player_stats_slipt%>%
  training()

###POPULATING THE TESTING DATASET
player_stats_test<- player_stats_slipt%>%
  testing()

glimpse(player_stats_train)
glimpse(player_stats_test)


decision_tree_model <- rpart(category ~ ., data = player_stats_train, method = "class")

##PREDICTING THE MODEL
predictions <- predict(decision_tree_model, newdata = player_stats_test, type = "class")

## CREATING A CONFUSION MATRIX
actual <- player_stats_test$category
confusion_matrix <- table(predictions, actual)
print(confusion_matrix)



##CALCULATING ACCURACY FROM THE CONFUSION MATRIX 
accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)
print(accuracy)

##PLOTTING THE DECISION TREE MODEL
rpart.plot(decision_tree_model,extra=101)



####### AUC ROC CURVE FOR DECISION TREES
# Convert 'actual' and 'predictions' to factors
actual <- factor(actual)
predictions <- factor(predictions)

# Create a list to store ROC objects for each class
roc_curves <- list()

# Calculate AUC-ROC curve for each class (one-vs-all)
for (class_label in levels(actual)) {
  binary_actual <- factor(ifelse(actual == class_label, "Positive", "Negative"), levels = c("Positive", "Negative"))
  binary_predicted <- factor(ifelse(predictions == class_label, "Positive", "Negative"), levels = c("Positive", "Negative"))
  
  roc_obj <- roc(binary_actual, as.numeric(binary_predicted))
  roc_curves[[class_label]] <- roc_obj
}




# Calculate macro-average AUC value
auc_values <- sapply(roc_curves, function(roc_obj) roc_obj$auc)
valid_auc_values <- auc_values[!is.na(auc_values) & sapply(auc_values, is.numeric)]
macro_auc_value <- mean(valid_auc_values, na.rm = TRUE)

# Print macro-average AUC value
cat("Macro-average AUC-ROC value:", macro_auc_value, "\n")

# Plot ROC curves for each class
par(mfrow = c(1, length(roc_curves)))
for (i in seq_along(roc_curves)) {
  plot(roc_curves[[i]], col = rainbow(1), main = paste("ROC Curve for Class", levels(actual)[i]), ExcellentGoodAveragePoor = 2)
}

# Add legend
legend_labels <- sapply(roc_curves, function(roc_obj) paste("Class", roc_obj$levels[[2]], "AUC =", round(roc_obj$auc, 2)))
legend("bottomright", legend = legend_labels, col = rainbow(length(roc_curves)),ExcellentGoodAveragePoor=2)

###########################################################################################

#NEURAL NETWORK MODEL

##USING OUR NUMERIC DATASET
glimpse(clean_player_stats)


###PARTITIONING MY DATASET INTO 70% TRAINING, 30% TESTING
player_stats_slipt<-initial_split(clean_player_stats,prop = 0.7,
                                  strata = category)


###POPULATING THE TRAINING DATASET
player_stats_train<- player_stats_slipt%>%
  training()

###POPULATING THE TESTING DATASET
player_stats_test<- player_stats_slipt%>%
  testing()

glimpse(player_stats_train)
glimpse(player_stats_test)

##FITTING THE NEURAL NETWORK MODEL
nn<- neuralnet(category~ gameNumber+Disposals+Kicks+Marks+Handballs+Goals+Tackles+Rebounds+Inside.50s+Clearances+Clangers+Contested.Possessions+Uncontested.Possessions+Contested.Marks+Marks.Inside.50+One.Percenters
               +Goal.Assists+Percentage.Played, data = player_stats_train,
               hidden = 2, act.fct = "logistic",
               linear.output = FALSE)
plot(nn)


player_stats_train$category <- factor(player_stats_train$category, c("1", "2", "3", "4"),
                             label= c("Poor", "Average", "Good", "Excellent"))



player_stats_test$category <- factor(player_stats_test$category, c("1", "2", "3", "4"),
                            label= c("Poor", "Average", "Good", "Excellent"))


Predict <- compute(nn, player_stats_test)
Predict
Predict$net.result


#CONVERTING THE PROBABILITIES INTO BINARY CLASSES "Excellent","Good", "Average", and "Poor"
prob <- Predict$net.result
threshold<- 76
pred <- ifelse(prob > threshold, "Excellent",ifelse(prob < (100 - threshold* 2), "Good",
                                                    ifelse(prob < (100 - threshold ), "Average", "Poor")))
pred                                                
                                                
actual <- player_stats_test$category


##CREATING THE CONFUSION MATRIX
table(pred, actual)

#ACCURACY
mean(pred ==actual)

#########################################################################################

#MODEL COMPARISON

###VISUALIZING ACCURACIES
# Create a list with model names and their corresponding accuracies
model_data <- list(
  Model = c("KNN", "Decision Tree", "Random Forest", "Neural Network"),
  Accuracy = c(0.96, 1, 0.99, 0.02)
)

# Convert the list to a data frame
model_accuracy <- data.frame(model_data)


# Create the bar chart
ggplot(model_accuracy, aes(x = Model, y = Accuracy)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "Accuracy Comparison of Models",
       x = "Model",
       y = "Accuracy") +
  theme_minimal()


####################################################################################################################









