
setwd("C:/Users/HP/Desktop/New folder")
set.seed(123456)
library(tidymodels)
library(dplyr)
library(ggplot2)
library(ggfortify)
library(stats)

#### META DATA ###
"https://www.kaggle.com/datasets/ronaldonyango/global-suicide-rates-1990-to-2022"

###Data Sources ####
"World Health Organization (WHO) Suicide Prevention: https://www.who.int/health-topics/suicide (Data on suicide rates and demographics)"

"World Bank Open Data: https://data.worldbank.org/ (Data on economic indicators like GDP, GNI, inflation, and employment)"

### UPLOAD DATA 
df1<-read.csv("C:/Users/HP/Desktop/New folder/suicide_rates_1990-2022.csv")
glimpse(df1)
str(df1)
summary(df1)


# Check for missing values
print (missing_values <- sum(is.na(df1)))

#The number of missing values for each column
print(missing_values <- colSums(is.na(df1)))

# Remove rows with missing values
cleaned_data <- na.omit(df1)
glimpse(cleaned_data)

# Visualize outliers
boxplot(cleaned_data$SuicideCount)

# Calculate the quartiles and IQR
Q1 <- quantile(cleaned_data$SuicideCount, 0.25)
Q3 <- quantile(cleaned_data$SuicideCount, 0.75)
IQR <- Q3 - Q1
print(IQR)

# Define the lower and upper bounds for outlier detection
lower_bound <- Q1 - 1.5 * IQR
upper_bound <- Q3 + 1.5 * IQR

# Filter out rows with suicide counts outside the bounds
cleaned_data <- cleaned_data[(cleaned_data$SuicideCount > lower_bound & cleaned_data$SuicideCount < upper_bound), ]


#Determine the range of suicide counts in the data
suicide_count_range <- range(cleaned_data$SuicideCount)


# Visualize suicide count over the years
ggplot(cleaned_data, aes(x = Year, y = SuicideCount)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "Suicide Count Over the Years", x = "Year", y = "Suicide Count") +
  theme_minimal()

# Visualize suicide count by age group using a bar plot
ggplot(cleaned_data, aes(x = AgeGroup, y = SuicideCount)) +
  geom_bar(stat = "identity", fill = "lightgreen") +
  labs(title = "Suicide Count by Age Group", x = "Age Group", y = "Suicide Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels if needed

# Visualize suicide count by age group using a bar plot
ggplot(cleaned_data, aes(x = Sex, y = SuicideCount)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "Suicide Count by Sex", x = "Sex", y = "Suicide Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels if needed

# Visualize suicide count by age group using a bar plot
ggplot(cleaned_data, aes(x = Generation, y = SuicideCount)) +
  geom_bar(stat = "identity", fill = "violet") +
  labs(title = "Suicide Count by Generation", x = "Generation", y = "Suicide Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels if needed


# Visualize suicide count by region using a bar plot
ggplot(cleaned_data, aes(x = RegionName, y = SuicideCount, fill = RegionName)) +
  geom_bar(stat = "identity") +
  labs(title = "Suicide Count by Region", x = "Region", y = "Suicide Count") +
  theme_minimal()


# Aggregate GDP by region
region_gdp <- aggregate(GDP ~ RegionName, data = cleaned_data, FUN = sum)

# Sort regions by GDP
region_gdp <- region_gdp[order(region_gdp$GDP, decreasing = TRUE), ]

# Create bar plot
ggplot(region_gdp, aes(x = reorder(RegionName, GDP), y = GDP)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "GDP by Region", x = "Region", y = "GDP") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# Aggregate population by region
region_population <- aggregate(Population ~ RegionName, data = cleaned_data, FUN = sum)

# Sort regions by population
region_population <- region_population[order(region_population$Population, decreasing = TRUE), ]

# Create bar plot
ggplot(region_population, aes(x = reorder(RegionName, Population), y = Population)) +
  geom_bar(stat = "identity", fill = "lightgreen") +
  labs(title = "Population by Region", x = "Region", y = "Population") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Compute the correlation matrix
correlation_matrix <- cor(cleaned_data[, numerical_cols])

# Print the correlation matrix
print(correlation_matrix)

# Visualize correlation matrix of numerical variables
correlation_matrix <- cor(cleaned_data[, numerical_cols])
correlation_df <- reshape2::melt(correlation_matrix)

ggplot(correlation_df, aes(x = Var1, y = Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "blue") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Correlation Matrix of Numerical Variables", x = "", y = "")



##################################################################################

### Clustering ######

# Standardize numerical values
numerical_cols <- c("SuicideCount", "CauseSpecificDeathPercentage", "DeathRatePer100K", "Population", "GDP", "GDPPerCapita", "GrossNationalIncome", "GNIPerCapita", "InflationRate", "EmploymentPopulationRatio")

cleaned_data[numerical_cols] <- scale(cleaned_data[numerical_cols])


# Select numerical features for clustering
numerical_features <- cleaned_data[, c("SuicideCount", "Population", "GDP", "GDPPerCapita", "GrossNationalIncome", "GNIPerCapita", "InflationRate", "EmploymentPopulationRatio")]


# Determining the optimal number of clusters using the elbow method
# Fit k-means models for different values of k
wss <- numeric(10)
for (i in 1:10) {
  kmeans_model <- kmeans(numerical_features, centers = i)
  wss[i] <- sum(kmeans_model$withinss)
}
# Map the clusters to the data points
cluster <- data.frame(numerical_features, kmeans_model$cluster)
colnames(cluster)[ncol(cluster)] <- "cluster"  # Rename the last column to 'cluster'
head(cluster)

# Plot the elbow curve
elbow_df <- data.frame(k = 1:10, tot_withinss = wss)
library(ggplot2)
ggplot(elbow_df, aes(x = k, y = tot_withinss)) +
  geom_line() +
  geom_point() +
  scale_x_continuous(breaks = 1:10) +
  labs(title = "Elbow Plot for Suicide Data", x = "Number of Clusters (k)", y = "Total Within-cluster Sum of Squares") +
  theme_minimal()


########## K Means Cluster 
# Perform k-means clustering with k = 4
KM= kmeans(numerical_features,4)

# Cluster Plot
autoplot(KM,numerical_features,frame=TRUE)

# cluster Centers
KM$centers


