##Importing libraries##
install.packages("kernlab")
install.packages("dplyr")
install.packages("tidymodels")
library(tidymodels)
library(tidymodels)
library(kernlab)
library(dplyr)
set.seed(1000)

#Source of data 1:https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
#Source of data 2:https://www.kaggle.com/datasets/vikasukani/diabetes-data-set



###### importation of the two datasets #########
setwd("C:/Users/brigh/OneDrive/Documents/DATA ANALYSIS/DIABETES")
data1 <- read.csv("diabetes.csv")
data2 <- read.csv("diabetes-dataset.csv")
view(data2)
####### Merge the two datasets; data1 and data2 using rbind #######
diabetes <- rbind(data1, data2)
nrow(diabetes)

diabetes$Outcome <- as.factor(diabetes$Outcome)
glimpse(diabetes)
diabetes%>% head()
diabetes%>% summary()

####### Check for missing values #######
missing_values <- sum(is.na(diabetes))

cat("Number of missing values in the dataset:", missing_values, "\n")
# It seems from the data there are zero entries in BMI ,
# Blood Pressure, Glucose, Skin Thickness and Insulin 
# which are meaningless so we will fill it with their median values
# The median is a robust statistic that is less sensitive to outliers 
# compared to the mean, making it a suitable choice for imputing missing values.

# Calculate the median for each column
median_bmi <- median(diabetes$BMI, na.rm = TRUE)
median_blood_pressure <- median(diabetes$BloodPressure, na.rm = TRUE)
median_glucose <- median(diabetes$Glucose, na.rm = TRUE)
median_skin_thickness <- median(diabetes$SkinThickness, na.rm = TRUE)
median_insulin <- median(diabetes$Insulin, na.rm = TRUE)

# Replace the zeros with the respective median values
diabetes$BMI[diabetes$BMI == 0] <- median_bmi
diabetes$BloodPressure[diabetes$BloodPressure == 0] <- median_blood_pressure
diabetes$Glucose[diabetes$Glucose == 0] <- median_glucose
diabetes$SkinThickness[diabetes$SkinThickness == 0] <- median_skin_thickness
diabetes$Insulin[diabetes$Insulin == 0] <- median_insulin

glimpse(diabetes)


##### Data partition/resampling leveraging the Rsample package in Tidymodel #####
diabetes_split <- initial_split(diabetes, prop = 0.75, strata = Outcome)

#Populate the training set
diabetes_training <- diabetes_split%>% 
  training()

#Populate the testing set
diabetes_test <- diabetes_split%>%
  testing()
diabetes_test

###### Feature Engineering with recipes package #######

# creating a preprocessing pipeline for the dataset diabetes

diabetes_recipe <- recipe(Outcome ~ ., data = diabetes_training) %>%
  #removes highly correlated numeric predictors
  step_corr(all_numeric(), threshold = .8)%>%
  
  # Normalize numeric predictors
  step_normalize(all_numeric())

diabetes_recipe 

#Explore the summary
diabetes_recipe %>% 
  summary()

#Train the Recipe object , using the prep() function
diabetes_recipe_prep <- diabetes_recipe %>% 
  prep(training = diabetes_training)

diabetes_recipe_prep

#Transforming the training data, using bake() function
diabetes_training_baked<- diabetes_recipe_prep%>%
  bake(new_data = NULL)
view(diabetes_training_baked)

#Transforning the test data 
diabetes_test_baked<- diabetes_recipe_prep%>%
  bake(new_data = diabetes_test)
view(diabetes_test_baked)

########  Modeling using Parsnip package ###########
# Logistic Regression 
#model specification 
diabetes_logistic_model <- logistic_reg()%>%
  set_engine('glm')%>%
  set_mode('classification')

#Model fitting 
diabetes_logistic_fit<- diabetes_logistic_model%>%
  fit(Outcome ~ ., 
      data = diabetes_training_baked)
diabetes_logistic_fit

#predicting outcome categories
class_preds_log<- predict(diabetes_logistic_fit, 
                          new_data = diabetes_test_baked,
                          type = "class")

#Predicting Outcome probabilities 
prob_preds_log <- predict(diabetes_logistic_fit, 
                          new_data = diabetes_test_baked,
                          type = "prob")

# combine test set results
diabetes_test_results_log <- diabetes_test%>%
  select(Outcome)%>%
  bind_cols(class_preds_log, prob_preds_log)
diabetes_test_results_log

#Model Performance Evaluation using Yardstick package 
# Confusion Matrix
Conf_mat_log <- diabetes_test_results_log%>%
  conf_mat(truth = Outcome, 
           estimate = .pred_class)
Conf_mat_log

# Accuracy 
Accuracy_log <- accuracy(diabetes_test_results_log,
                         truth = Outcome,
                         estimate = .pred_class)
Accuracy_log

# Sensitivity 
Sensitivity_log <- diabetes_test_results_log%>%
  sens(truth= Outcome,
       estimate = .pred_class )
Sensitivity_log

# Specificity 
Specificity_log <- diabetes_test_results_log%>%
  spec(truth = Outcome, 
       estimate = .pred_class)
Specificity_log

# ROC curve
diabetes_test_results_log%>%
  roc_curve(truth = Outcome, 
            .pred_0)%>%
  autoplot()

#Area under the curve , Roc auc
Roc_auc_log <- diabetes_test_results_log%>%
  roc_auc(truth = Outcome, 
          .pred_0)
Roc_auc_log

#area under the curve is 85.7 % this indicates that the model gets
# a B in terms of overall model performance. 

#### Decision Tree Modeling #######
# Decision Tree model specification
diabetes_tree_model <- decision_tree(tree_depth = 5) %>%
  set_engine("rpart") %>%
  set_mode("classification")


# Decision Tree Model fitting 
diabetes_tree_fit <- diabetes_tree_model %>%
  fit(Outcome ~ ., data = diabetes_training_baked)

# Predictions - Class Labels:
class_preds_tree <- predict(diabetes_tree_fit, new_data = diabetes_test_baked, type = "class")

#Predictions - Probabilities:
prob_preds_tree <- predict(diabetes_tree_fit, new_data = diabetes_test_baked, type = "prob")


# Combine the true "Outcome" values from the test set with 
# the predicted class labels and probabilities.
diabetes_test_results_tree <- diabetes_test %>%
  select(Outcome) %>%
  bind_cols(class_preds_tree, prob_preds_tree)

#### Model Performance Evaluation using Yardstick package ####

# Confusion Matrix
conf_matrix_tree <- diabetes_test_results_tree %>%
  conf_mat(truth = Outcome, estimate = .pred_class)
conf_matrix_tree

# Accuracy
accuracy_tree <- accuracy(diabetes_test_results_tree, truth = Outcome, estimate = .pred_class)
accuracy_tree

# Sensitivity
sensitivity_tree <- diabetes_test_results_tree %>%
  sens(truth = Outcome, estimate = .pred_class)
sensitivity_tree

# Specificity
specificity_tree <- diabetes_test_results_tree %>%
  spec(truth = Outcome, estimate = .pred_class)
specificity_tree

# ROC Curve
roc_curve_tree <- diabetes_test_results_tree %>%
  roc_curve(truth = Outcome, .pred_0) %>%
  autoplot()
roc_curve_tree

# Area Under the Curve (AUC)
roc_auc_tree <- diabetes_test_results_tree %>%
  roc_auc(truth = Outcome, .pred_0)
roc_auc_tree

#Area under the curve is 77.2 % this indicates that the Decision tree model gets
# a C in terms of overall model performance.


######## Support Vector Machine Modeling ##########

# Create an SVM model specification
diabetes_svm_model <- svm_poly() %>%
  set_mode("classification") %>%
  set_engine("kernlab")

# Fit the SVM model
diabetes_svm_fit <- diabetes_svm_model %>%
  fit(Outcome ~ ., data = diabetes_training_baked)

# Predict outcome categories
class_preds_svm <- predict(diabetes_svm_fit, new_data = diabetes_test_baked)

# Predict outcome probabilities
prob_preds_svm <- predict(diabetes_svm_fit, new_data = diabetes_test_baked, type = "prob")

# Combine test set results
diabetes_test_results_svm <- diabetes_test %>%
  select(Outcome) %>%
  bind_cols(class_preds_svm, prob_preds_svm)

# Model Performance Evaluation using Yardstick package
# Confusion Matrix
conf_mat_svm <- diabetes_test_results_svm %>%
  conf_mat(truth = Outcome, estimate = .pred_class)
conf_mat_svm

# Accuracy
accuracy_svm <- accuracy(diabetes_test_results_svm, truth = Outcome, estimate = .pred_class)
accuracy_svm

# Sensitivity
sensitivity_svm <- diabetes_test_results_svm %>%
  sens(truth = Outcome, estimate = .pred_class)
sensitivity_svm

# Specificity
specificity_svm <- diabetes_test_results_svm %>%
  spec(truth = Outcome, estimate = .pred_class)
specificity_svm

# ROC curve
roc_curve_smv <- diabetes_test_results_svm %>%
  roc_curve(truth = Outcome, .pred_0)%>%
  autoplot
roc_curve_smv

# Area under the ROC curve (AUC-ROC)
roc_auc_svm <- diabetes_test_results_svm %>%
  roc_auc(truth = Outcome, .pred_0)
roc_auc_svm

#area under the curve is 85.4 % this indicates that the model gets
# a B in terms of overall model performance.

